
public class Fractal {

	public static void main(String[] args) {
		int iteration = Integer.parseInt(args[0]);
		
		double height = Math.sqrt(3)/3;
		double[] lat = {0.0, 0.5, 1.0};
		double[] lon = {0.0, height, 0.0};
		
		StdDraw.setPenRadius(0.001);
		double x = 0, y = 0;
		for (int t = 0; t < iteration; t++)
		{
			int s = (int)Math.random()*3;
			x = (x + lat[s])/2.0;
			y = (y + lon[s])/2;
			StdDraw.point(x, y);
		}
		

	}

}
