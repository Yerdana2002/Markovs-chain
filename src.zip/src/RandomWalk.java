
public class RandomWalk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = Integer.parseInt(args[0]);
		int trials = Integer.parseInt(args[1]);
		int deadends = 0;
		
		for (int t = 0; t < trials; t++)
		{
			boolean[][] map = new boolean[n][n];
			int row = n/2; int col = n/2;
			// while the dog is not on outermost edges
			while (row > 0 && col > 0 && row < n-1 & col < n-1)
			{
				// repeatedly check whether the dog has hit a dead end
				if (map[row+1][col] && map[row-1][col] && map[row][col+1] && map[row][col-1])
				{
					deadends++;
					break;
				}
				map[row][col] = true;
				
				//check for neighboring spots, go randomly if they are not visited
				
				double r = Math.random();
				if (r<0.25)
				{
					if (!map[row+1][col])
						row++;
				}
				else if (r<0.5)
				{
					if (!map[row-1][col])
						row--;
				}
				else if (r<0.75)
				{
					if(!map[row][col+1])
						col++;
				}
				else if (r<1)
				{
					if(!map[row][col-1])
						col--;
				}
				
			}
		}
		
		System.out.println(100 * deadends/trials + "%");
		
	}

}
