
public class RandomSurfer {

	public static void main(String[] args) {
		// input number of trials
		int trials = Integer.parseInt(args[0]);
		// initializing 2d array and taking transition matrix
		int n = Integer.parseInt(args[1]);
		
		double[][] matrix = new double[n][n];
		
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < n; j++)
			{
				matrix[i][j] = StdIn.readDouble();
			}
		}
		
		// initializing frequency table
		
		int[] frequency = new int[n];
		
		// starting from page 0
		int page = 0;  
		
		/*
		 * plotting histogram of frequency table
		 */
		
			StdDraw.enableDoubleBuffering();
			
		
		for (int i = 0; i < trials; i++)
		{
			double r = Math.random();
			double sum = 0.0;
			for (int j = 0; j < n; j++)
			{
				sum+=matrix[page][j];
				if (r < sum)
				{
					page = j;
					break;
				}
			}
			frequency[page]++;
			
			StdDraw.clear();
            StdDraw.setXscale(-1, n);
            StdDraw.setYscale(0, trials);
            for (int k = 0; k < n; k++) {
                StdDraw.filledRectangle(k, frequency[k]/2.0, 0.25, frequency[k]/2.0);
            }
            StdDraw.show();
            StdDraw.pause(20);
		}
		
		
		// printing page ranks
		for (int i = 0; i < n; i++)
		{
			System.out.println(frequency[i]/trials);
		}
		
	
	
	
		

	}
}

