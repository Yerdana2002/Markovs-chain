
public class Transition {

	public static void main(String[] args) {
		// Create input stream for number of webpages
		int n = StdIn.readInt();
		//matrix to write our frequency data into
		int[][] frequency = new int[n][n];
		//the table summarizing the frequencies from each page
		int[] outdegrees = new int[n];
		
		//assume that every page has link to it
		while(!StdIn.isEmpty())
		{
			int orig = StdIn.readInt();
			int dest = StdIn.readInt();
			frequency[orig][dest]++;
			outdegrees[orig]++;
		}
	
		//calculating probability distribution to transition matrix
		
		double[][] transition = new double[n][n];
		
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < n; j++)
			{
				transition[i][j] = ((frequency[i][j]*0.9)/outdegrees[i]) + 0.1/n;
				StdOut.print(transition[i][j] + " ");
			}
			StdOut.print("\n");
		}
		

		
	

	}

}
