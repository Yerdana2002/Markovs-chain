/*
 * program takes int input representing number of players
 * it shuffles cards, deals 5-card hands to specified number of players
 */
public class Deal {

	public static void main(String[] args) {
		//defining constant values
		
		int CARDS = 52;
		int CARDS_IN_HAND = 5;
		
		int players = Integer.parseInt(args[0]);
		
		String[] SUITS = {"Clubs", "Diamonds", "Spades", "Hearts"};
		String[] RANKS = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
		
		
		
		if (players*CARDS_IN_HAND>52)
			throw new RuntimeException("Too many players");
		
		//Initializing a deck
		
		String[] deck = new String[52];
		for (int i=0; i < RANKS.length; i++)
		{
			for (int j=0; j < SUITS.length; j++)
			{
				deck[i*SUITS.length + j] = RANKS[i] + " of " + SUITS[j];
			}
		}
		// shuffling a deck
		for (int i = 0; i < deck.length; i++)
		{
			int r = i + (int)(Math.random() * (deck.length-i));
			String temp = deck[i];
			deck[i] = deck[r];
			deck[r] = temp;
		}
		
		//printing out the deck
		for (int i=0; i < players*5; i++)
		{
			System.out.println(deck[i]);
			if (i%CARDS_IN_HAND==CARDS_IN_HAND-1)
				System.out.println();
		}
		
	}

}
